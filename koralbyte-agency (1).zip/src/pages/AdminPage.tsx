import React, { useState, useEffect } from "react";
import { GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged, User } from "firebase/auth";
import { collection, addDoc, getDocs, deleteDoc, doc, serverTimestamp, query, orderBy } from "firebase/firestore";
import { auth, db } from "../lib/firebase";
import type { PortfolioItem } from "../data/portfolio";

export function AdminPage() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [portfolioItems, setPortfolioItems] = useState<(PortfolioItem & { id: string })[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [permissionError, setPermissionError] = useState(false);
  const [formData, setFormData] = useState({
    title: "",
    category: "Strategy",
    image: "",
    industry: "",
    challenge: "",
    solution: "",
    order: 0,
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
      if (currentUser?.email === 'alinourawan123@gmail.com') {
        fetchPortfolio();
      }
    });
    return () => unsubscribe();
  }, []);

  const fetchPortfolio = async () => {
    try {
      const q = query(collection(db, 'portfolio'), orderBy('order', 'asc'));
      const snapshot = await getDocs(q);
      const items = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as PortfolioItem & { id: string }));
      setPortfolioItems(items);
      if (items.length > 0) {
        setFormData(prev => ({ ...prev, order: items.length }));
      }
      setPermissionError(false);
    } catch (error: any) {
      if (error?.code === 'permission-denied') {
        setPermissionError(true);
      }
      console.error("Error fetching portfolio:", error);
    }
  };

  const handleLogin = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed:", error);
      alert("Login failed. See console.");
    }
  };

  const handleLogout = async () => {
    await signOut(auth);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setIsSubmitting(true);

    try {
      await addDoc(collection(db, 'portfolio'), {
        ...formData,
        createdAt: serverTimestamp()
      });
      alert("Successfully added portfolio item!");
      setFormData({
        title: "",
        category: "Strategy",
        image: "",
        industry: "",
        challenge: "",
        solution: "",
        order: formData.order + 1,
      });
      fetchPortfolio();
    } catch (error) {
      console.error("Error adding doc:", error);
      alert("Failed to add piece. Are you sure you are logged in with alinourawan123@gmail.com?");
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this piece?")) return;
    try {
      await deleteDoc(doc(db, 'portfolio', id));
      fetchPortfolio();
    } catch (error) {
      console.error("Error deleting:", error);
      alert("Delete failed.");
    }
  };

  if (loading) return <div className="pt-32 px-10 text-white font-mono">Loading...</div>;

  if (!user || user.email !== 'alinourawan123@gmail.com') {
    return (
      <div className="pt-32 pb-32 px-5 md:px-10 max-w-xl mx-auto text-center flex flex-col items-center">
        <h1 className="text-3xl font-bold text-white mb-6">Admin Access</h1>
        <p className="text-white/90 mb-8">Secure area. You must login with authorized account.</p>
        <button 
          onClick={handleLogin}
          className="bg-white text-black font-bold tracking-widest uppercase px-8 py-4 hover:bg-white/90 transition-colors"
        >
          Sign In with Google
        </button>
        {user && user.email !== 'alinourawan123@gmail.com' && (
          <p className="text-red-400 mt-4 font-mono text-sm">Access denied for {user.email}.</p>
        )}
      </div>
    );
  }

  return (
    <div className="pt-24 pb-32 px-5 md:px-10 max-w-5xl mx-auto space-y-16">
      <div className="flex justify-between items-center border-b border-white/60 pb-8">
        <div>
          <h1 className="text-4xl font-bold text-white">Admin Dashboard</h1>
          <p className="text-bauble-blue font-mono mt-2">{user.email}</p>
        </div>
        <button onClick={handleLogout} className="border border-white/40 text-white px-4 py-2 font-mono text-xs hover:bg-black/40 transition-colors">Logout</button>
      </div>

      {permissionError && (
        <div className="bg-red-500/10 border border-red-500/30 p-6 rounded-lg mb-8">
          <h3 className="text-red-400 font-bold mb-2">Firestore Permissions Need Update</h3>
          <p className="text-white/80 text-sm mb-4">
            Because a named database was used, the built-in deploy tool couldn't automatically secure your database. 
            To test the admin functionality, you MUST update the rules in the Firebase Console.
          </p>
          <ol className="list-decimal pl-5 text-sm space-y-2 text-white font-mono">
            <li>Go to <a href="https://console.firebase.google.com/" target="_blank" rel="noreferrer" className="text-bauble-blue underline">Firebase Console</a> and open your project.</li>
            <li>Go to <strong>Firestore Database</strong> -&gt; click the dropdown and select <strong>coral-byte-data</strong>.</li>
            <li>Go to the <strong>Rules</strong> tab.</li>
            <li>Open the `firestore.rules` file from this project and copy its entire contents.</li>
            <li>Paste it into the Firebase console and click <strong>Publish</strong>.</li>
            <li>Refresh this page.</li>
          </ol>
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-12">
        {/* ADD NEW FORM */}
        <div className="space-y-8">
          <h2 className="text-2xl font-bold text-white">Add Portfolio Piece</h2>
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div>
              <label className="block text-[10px] text-white/80 uppercase tracking-widest mb-2 font-mono">Title</label>
              <input required value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} className="w-full bg-black border border-white/40 px-4 py-3 text-white focus:outline-none focus:border-bauble-blue transition-colors" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] text-white/80 uppercase tracking-widest mb-2 font-mono">Category</label>
                <select value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="w-full bg-black/10 border border-white/10 shadow-inner px-4 py-3 text-white focus:outline-none focus:border-bauble-blue transition-colors appearance-none">
                  <option>Strategy</option>
                  <option>Identity</option>
                  <option>Growth</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] text-white/200 uppercase tracking-widest mb-2 font-mono">Industry</label>
                <input required value={formData.industry} onChange={e => setFormData({...formData, industry: e.target.value})} placeholder="e.g. F&B, Tech" className="w-full bg-white/30 border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-bauble-blue transition-colors" />
              </div>
            </div>
            <div>
              <label className="block text-[10px] text-white/50 uppercase tracking-widest mb-2 font-mono">Main Image URL</label>
              <input type="url" required value={formData.image} onChange={e => setFormData({...formData, image: e.target.value})} placeholder="https://..." className="w-full bg-white/5 border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-bauble-blue transition-colors" />
              <p className="text-[10px] text-white/70 mt-1 font-mono">Any size works. Images will automatically be cropped to fit the perfectly uniform 4:5 grid.</p>
            </div>
            <div>
              <label className="block text-[10px] text-white/50 uppercase tracking-widest mb-2 font-mono">The Challenge (Optional)</label>
              <textarea value={formData.challenge} onChange={e => setFormData({...formData, challenge: e.target.value})} className="w-full bg-white/5 border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-bauble-blue transition-colors min-h-[100px]" />
            </div>
            <div>
              <label className="block text-[10px] text-white/50 uppercase tracking-widest mb-2 font-mono">The Solution (Optional)</label>
              <textarea value={formData.solution} onChange={e => setFormData({...formData, solution: e.target.value})} className="w-full bg-white/5 border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-bauble-blue transition-colors min-h-[100px]" />
            </div>
            <div>
              <label className="block text-[10px] text-white/50 uppercase tracking-widest mb-2 font-mono">Order Index</label>
              <input type="number" required value={formData.order} onChange={e => setFormData({...formData, order: parseInt(e.target.value)})} placeholder="e.g. 0" className="w-full bg-white/5 border border-white/10 px-4 py-3 text-white focus:outline-none focus:border-bauble-blue transition-colors" />
            </div>
            
            <button type="submit" disabled={isSubmitting} className="w-full py-4 bg-bauble-blue text-white font-bold tracking-widest uppercase disabled:opacity-50">
              {isSubmitting ? "Adding..." : "Add to Portfolio"}
            </button>
          </form>
        </div>

        {/* EXISTING LIST */}
        <div className="space-y-8">
          <h2 className="text-2xl font-bold text-white">Manage Existing</h2>
          <div className="space-y-4">
            {portfolioItems.map(item => (
              <div key={item.id} className="flex gap-4 border border-white/10 p-4 bg-black items-center">
                <img src={item.image} alt="" className="w-16 h-20 object-cover" />
                <div className="flex-1 min-w-0">
                  <h4 className="text-white font-bold truncate">{item.title}</h4>
                  <p className="text-xs text-white/50 font-mono">{item.category} • {item.industry} • Order: {item.order}</p>
                </div>
                <button onClick={() => handleDelete(item.id)} className="text-red-400 font-mono text-xs hover:text-red-300">Delete</button>
              </div>
            ))}
            {portfolioItems.length === 0 && <p className="text-white/70 font-mono">No items found.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}
