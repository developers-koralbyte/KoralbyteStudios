import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Linkedin, Twitter, Mail, X } from "lucide-react";

export function TeamPage() {
  const [showPopup, setShowPopup] = useState(false);

  const teamMembers = [
    { 
      name: "Ibn E Ali Syed", 
      role: "CEO", 
      image: "https://api.dicebear.com/7.x/avataaars/svg?seed=IbnEAli&style=transparent&top=shortHairTheCaesar&clothes=blazerAndShirt",
      bio: "The finance guy and the dealmaker. Ali brings the architecture that turns ambitious ideas into fundable, scalable realities. He has built and exited multiple seven-figure brands and knows exactly which doors to open, and when."
    },
    { 
      name: "Aniq Javed", 
      role: "CMO", 
      image: "https://api.dicebear.com/7.x/avataaars/svg?seed=Aniq&style=transparent&top=shortHairShortFlat&clothes=hoodie",
      bio: "The marketing and strategy genius. Aniq has lived it all. From online storefronts to retail storefronts, from zero followers to retail distributions. Eleven personal brands built from scratch. Every one of them scaled. If there is a growth lever, he has already pulled it."
    }
  ];

  return (
    <div className="relative z-20 pt-24 pb-32 overflow-hidden">
      {/* Header section with technical visual */}
      <section className="px-5 md:px-10 max-w-7xl mx-auto mb-24 md:mb-32 relative">
         <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-20 pt-8 md:pt-16">
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8 }}
              className="flex-1 space-y-6 md:space-y-8 text-center lg:text-left z-10 relative"
            >
               <div className="flex items-center justify-center lg:justify-start gap-3 text-[9px] tracking-[0.3em] text-white uppercase">
                 <span className="text-bauble-blue italic">→</span> OUR MISSION
               </div>
               <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.05]">
                 To build brands that are <span className="text-bauble-blue">impossible to ignore</span> and positioned to dominate.
               </h1>
               <p className="text-white/80 font-mono text-sm md:text-lg max-w-xl leading-relaxed mx-auto lg:mx-0">
                 We embed ourselves in your brand, think like founders, and build like we have skin in the game. We are a concentrated unit of strategists. No fluff.
               </p>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 1.2, ease: "easeOut" }}
              className="hidden lg:flex flex-1 justify-end relative z-10"
            >
               <div className="relative w-[400px] h-[400px]">
                  {/* Central Node Visual */}
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 rounded-full border border-bauble-blue/30 bg-black/40 flex items-center justify-center shadow-[0_0_40px_rgba(105,104,172,0.3)] z-20">
                     <div className="w-12 h-12 rounded-full bg-bauble-blue/20 animate-pulse" />
                  </div>
                  
                  {/* Orbital Lines */}
                  <svg className="absolute inset-0 w-full h-full pb-0 pointer-events-none z-10" viewBox="0 0 400 400">
                     <circle cx="200" cy="200" r="120" fill="none" stroke="rgba(105,104,172,0.8)" strokeWidth="1" />
                     <circle cx="200" cy="200" r="160" fill="none" stroke="rgba(105,104,172,0.05)" strokeWidth="1" strokeDasharray="2 10" />
                     
                     <motion.path 
                       d="M200 200 L120 100" 
                       stroke="rgba(17,17,17,0.7)" 
                       strokeWidth="1" 
                       strokeDasharray="4 4"
                       initial={{ pathLength: 0 }}
                       animate={{ pathLength: 1 }}
                       transition={{ duration: 2, repeat: Infinity }}
                     />
                     <motion.path 
                       d="M200 200 L300 120" 
                       stroke="rgba(105,104,172,0.3)" 
                       strokeWidth="1" 
                       strokeDasharray="4 4"
                       initial={{ pathLength: 0 }}
                       animate={{ pathLength: 1 }}
                       transition={{ duration: 2, delay: 0.5, repeat: Infinity }}
                     />
                     <motion.path 
                       d="M200 200 L110 300" 
                       stroke="rgba(255,255,255,0.2)" 
                       strokeWidth="1" 
                       strokeDasharray="4 4"
                       initial={{ pathLength: 0 }}
                       animate={{ pathLength: 1 }}
                       transition={{ duration: 2, delay: 1, repeat: Infinity }}
                     />
                  </svg>

                  {/* Floating Tech Nodes */}
                  <div className="absolute top-[80px] left-[100px] w-20 h-20 rounded-xl border border-white/10 bg-black/40 backdrop-blur-2xl shadow-xl flex items-center justify-center z-20 hover:border-bauble-blue hover:scale-110 transition-all cursor-crosshair">
                     <Linkedin className="w-6 h-6 text-white/80" />
                  </div>
                  <div className="absolute top-[100px] right-[80px] w-16 h-16 rounded-xl border border-bauble-blue/20 bg-bauble-blue/5 backdrop-blur-md flex items-center justify-center z-20 hover:border-bauble-blue hover:scale-110 transition-all cursor-crosshair">
                     <Twitter className="w-5 h-5 text-bauble-blue/50" />
                  </div>
                  <div className="absolute bottom-[80px] left-[120px] w-14 h-14 rounded-xl border border-white/10 bg-black/30 flex items-center justify-center z-20 hover:border-bauble-blue hover:scale-110 transition-all cursor-crosshair">
                     <Mail className="w-5 h-5 text-white/200" />
                  </div>
               </div>
            </motion.div>
         </div>
         <div className="absolute top-1/2 left-1/2 md:left-[80%] w-[600px] h-[600px] bg-bauble-blue/25 blur-[150px] rounded-full -translate-y-1/2 -translate-x-1/2 z-0 pointer-events-none" />
      </section>

      {/* Team Section */}
      <section className="px-5 md:px-10 max-w-7xl mx-auto mb-20 md:mb-32">
        <div className="flex flex-col md:flex-row justify-center items-start gap-12 md:gap-16 lg:gap-24">
          {teamMembers.map((member, i) => (
            <motion.div 
              key={i} 
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="group cursor-default w-full max-w-[400px] flex flex-col"
            >
              <div className="aspect-[4/5] w-full bg-black/40 backdrop-blur-xl border border-white/10 relative overflow-hidden mb-6 group-hover:border-bauble-blue/50 transition-all duration-500 shadow-[0_0_0_rgba(105,104,172,0)] group-hover:shadow-[0_0_30px_rgba(105,104,172,0.9)] text-left shrink-0">
                <img src={member.image} alt={member.name} className="absolute inset-0 w-full h-full object-cover opacity-60 grayscale group-hover:grayscale-0 group-hover:opacity-100 transition-all duration-700 scale-105 group-hover:scale-100" />
                <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80" />
                <div className="absolute bottom-4 left-4 right-4 translate-y-4 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-500">
                   <div className="flex gap-2">
                      <div className="w-8 h-8 rounded-full border border-white/40 bg-black/40 flex items-center justify-center backdrop-blur-sm hover:border-bauble-blue hover:text-bauble-blue transition-colors">
                        <Linkedin className="w-3.5 h-3.5" />
                      </div>
                      <div className="w-8 h-8 rounded-full border border-white/50 bg-black/40 flex items-center justify-center backdrop-blur-sm hover:border-bauble-blue hover:text-bauble-blue transition-colors">
                        <Twitter className="w-3.5 h-3.5" />
                      </div>
                   </div>
                </div>
              </div>
              <div className="space-y-3">
                <div className="text-[10px] uppercase tracking-[0.2em] text-bauble-blue font-bold">
                  {member.role}
                </div>
                <h3 className="text-2xl md:text-3xl font-bold text-white group-hover:text-bauble-blue transition-colors">
                  {member.name}
                </h3>
                <p className="text-white/70 font-sans text-sm leading-relaxed">
                  {member.bio}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      {/* Recruiter / Join Section */}
      <section className="relative px-5 md:px-10 py-20 md:py-32 bg-bauble-blue/5 border-y border-bauble-blue/10 overflow-hidden flex items-center justify-center min-h-[400px]">
        {/* Main Section Content */}
        <div className={`max-w-4xl mx-auto text-center space-y-6 md:space-y-8 relative z-10 transition-opacity duration-500 ${showPopup ? 'opacity-0 pointer-events-none' : 'opacity-100'}`}>
          <div className="text-bauble-blue text-[9px] tracking-[0.4em] font-bold uppercase">Hiring</div>
          <h2 className="text-3xl md:text-6xl font-bold tracking-tight text-white italic">"Better as a collective."</h2>
          <p className="text-white/50 font-sans text-sm md:text-lg leading-relaxed max-w-2xl mx-auto">
            We are always looking for senior strategists and identity designers who are tired of the agency machine and want to build real brands with real outcomes.
          </p>
          <div className="pt-4">
             <button 
               onClick={() => setShowPopup(true)}
               className="text-[11px] font-bold tracking-[0.2em] text-white border-b-2 border-bauble-blue pb-1 hover:text-bauble-blue transition-colors"
             >
               VIEW OPEN POSITIONS →
             </button>
          </div>
        </div>

        {/* Popup specific to this section */}
        <AnimatePresence>
          {showPopup && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-20 flex items-center justify-center backdrop-blur-md bg-black/60 p-5 px-4"
            >
              <motion.div
                initial={{ scale: 0.95, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 20 }}
                className="bg-black/80 backdrop-blur-3xl border border-white/20 p-8 md:p-12 max-w-md w-full relative shadow-[0_0_40px_rgba(0,0,0,0.5)]"
              >
                <button 
                  onClick={() => setShowPopup(false)}
                  className="absolute top-4 right-4 text-white/50 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="text-center space-y-4 relative z-10">
                  <div className="w-16 h-16 rounded-full bg-bauble-blue/10 border border-bauble-blue/20 flex items-center justify-center mx-auto mb-6">
                    <Mail className="w-6 h-6 text-bauble-blue" />
                  </div>
                  <h3 className="text-2xl font-bold text-white tracking-tight">Not Hiring Right Now</h3>
                  <p className="text-white/70 font-sans text-sm leading-relaxed">
                    Oops! Looks like we're not hiring right now. You can check back later!
                  </p>
                  <button 
                    onClick={() => setShowPopup(false)}
                    className="mt-6 w-full py-4 text-[10px] uppercase tracking-[0.2em] font-bold bg-white text-black hover:bg-bauble-blue hover:text-white transition-all duration-300 shadow-[0_0_20px_rgba(255,255,255,0.1)] hover:shadow-[0_0_30px_rgba(105,104,172,0.4)]"
                  >
                    Close
                  </button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </section>
    </div>
  );
}


